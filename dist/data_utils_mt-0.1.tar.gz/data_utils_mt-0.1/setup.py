from setuptools import setup

setup(name='data_utils_mt',
      version='0.1',
      description='Utility functions for pandas and Data Analysis.',
      packages=['data_utils_mt'],
      author='Miguel Tasende',
      zip_safe=False)
